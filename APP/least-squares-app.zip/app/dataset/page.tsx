"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useAnalysis } from "@/lib/analysis-context"
import { SectionTitle } from "@/components/section-title"
import { Card } from "@/components/card"
import Papa from "papaparse"
import styles from "./page.module.css"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js"
import { Scatter } from "react-chartjs-2"

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend)

export default function DatasetPage() {
  const { dataset, setDataset } = useAnalysis()
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadCSV = async () => {
      try {
        const response = await fetch(
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Ejercicio%202-YDne4VoeGaLVikGpC56UIQjKS4vSBV.csv",
        )
        const csvText = await response.text()

        Papa.parse(csvText, {
          header: true,
          dynamicTyping: true,
          complete: (results) => {
            const data = results.data as any[]

            const validData = data
              .filter((row) => typeof row.wind_speed_ms === "number" && typeof row.power_kW === "number")
              .map((row) => ({
                velocidad: row.wind_speed_ms,
                potencia: row.power_kW,
              }))

            if (validData.length === 0) {
              setError("No se encontraron datos válidos en el CSV")
              setLoading(false)
              return
            }

            setDataset(validData)
            setError("")
            setLoading(false)
          },
          error: () => {
            setError("Error al leer el archivo CSV")
            setLoading(false)
          },
        })
      } catch (err) {
        setError("Error al cargar el archivo CSV desde la URL")
        setLoading(false)
      }
    }

    loadCSV()
  }, [setDataset])

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      complete: (results) => {
        const data = results.data as any[]

        if (data[0]?.wind_speed_ms !== undefined && data[0]?.power_kW !== undefined) {
          const validData = data
            .filter((row) => typeof row.wind_speed_ms === "number" && typeof row.power_kW === "number")
            .map((row) => ({
              velocidad: row.wind_speed_ms,
              potencia: row.power_kW,
            }))

          if (validData.length === 0) {
            setError("No se encontraron datos válidos")
            return
          }

          setDataset(validData)
          setError("")
        } else if (data[0]?.velocidad !== undefined && data[0]?.potencia !== undefined) {
          const validData = data.filter((row) => typeof row.velocidad === "number" && typeof row.potencia === "number")

          if (validData.length === 0) {
            setError("No se encontraron datos válidos")
            return
          }

          setDataset(validData)
          setError("")
        } else {
          setError('CSV debe contener columnas "wind_speed_ms" y "power_kW" o "velocidad" y "potencia"')
        }
      },
      error: () => {
        setError("Error al leer el archivo CSV")
      },
    })
  }

  const stats =
    dataset.length > 0
      ? {
          n: dataset.length,
          velocidadMin: Math.min(...dataset.map((d) => d.velocidad)),
          velocidadMax: Math.max(...dataset.map((d) => d.velocidad)),
          velocidadMean: dataset.reduce((sum, d) => sum + d.velocidad, 0) / dataset.length,
          potenciaMin: Math.min(...dataset.map((d) => d.potencia)),
          potenciaMax: Math.max(...dataset.map((d) => d.potencia)),
          potenciaMean: dataset.reduce((sum, d) => sum + d.potencia, 0) / dataset.length,
        }
      : null

  const scatterData = {
    datasets: [
      {
        label: "Datos observados",
        data: dataset.map((d) => ({ x: d.velocidad, y: d.potencia })),
        backgroundColor: "rgba(239, 68, 68, 0.6)",
        borderColor: "rgba(239, 68, 68, 1)",
        pointRadius: 5,
      },
    ],
  }

  const scatterOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "top" as const,
      },
      title: {
        display: true,
        text: "Velocidad del Viento vs Potencia",
      },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: "Velocidad del Viento (m/s)",
        },
      },
      y: {
        title: {
          display: true,
          text: "Potencia (kW)",
        },
      },
    },
  }

  if (loading) {
    return (
      <div className={styles.page}>
        <SectionTitle>Cargar Dataset</SectionTitle>
        <div className={styles.container}>
          <Card>
            <p className={styles.cardText}>Cargando datos...</p>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className={styles.page}>
      <SectionTitle>Cargar Dataset</SectionTitle>

      <div className={styles.container}>
        <Card>
          <h3 className={styles.cardTitle}>Subir archivo CSV</h3>
          <p className={styles.cardText}>
            El archivo debe contener columnas <code>wind_speed_ms</code> y <code>power_kW</code> (o{" "}
            <code>velocidad</code> y <code>potencia</code>)
          </p>

          <div className={styles.uploadArea}>
            <input type="file" accept=".csv" onChange={handleFileUpload} className={styles.fileInput} id="csv-upload" />
            <label htmlFor="csv-upload" className={styles.uploadLabel}>
              Seleccionar archivo CSV
            </label>
          </div>

          {error && <p className={styles.error}>{error}</p>}
        </Card>

        {stats && (
          <>
            <Card>
              <h3 className={styles.cardTitle}>Estadísticas básicas</h3>
              <div className={styles.stats}>
                <div className={styles.stat}>
                  <span className={styles.statLabel}>Observaciones:</span>
                  <span className={styles.statValue}>{stats.n}</span>
                </div>
                <div className={styles.stat}>
                  <span className={styles.statLabel}>Velocidad (min/max/media):</span>
                  <span className={styles.statValue}>
                    {stats.velocidadMin.toFixed(2)} / {stats.velocidadMax.toFixed(2)} / {stats.velocidadMean.toFixed(2)}
                  </span>
                </div>
                <div className={styles.stat}>
                  <span className={styles.statLabel}>Potencia (min/max/media):</span>
                  <span className={styles.statValue}>
                    {stats.potenciaMin.toFixed(2)} / {stats.potenciaMax.toFixed(2)} / {stats.potenciaMean.toFixed(2)}
                  </span>
                </div>
              </div>
            </Card>

            <Card>
              <h3 className={styles.cardTitle}>Gráfico de Dispersión</h3>
              <div style={{ height: "400px" }}>
                <Scatter data={scatterData} options={scatterOptions} />
              </div>
            </Card>

            <Card>
              <h3 className={styles.cardTitle}>Vista previa (primeras 20 filas)</h3>
              <div className={styles.tableWrapper}>
                <table className={styles.table}>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Velocidad (m/s)</th>
                      <th>Potencia (kW)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dataset.slice(0, 20).map((row, i) => (
                      <tr key={i}>
                        <td>{i + 1}</td>
                        <td>{row.velocidad.toFixed(2)}</td>
                        <td>{row.potencia.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </>
        )}
      </div>
    </div>
  )
}
