import { SectionTitle } from "@/components/section-title"
import { Card } from "@/components/card"
import styles from "./about.module.css"

export default function AboutPage() {
  return (
    <div className={styles.page}>
      <SectionTitle>Acerca del Proyecto</SectionTitle>

      <div className={styles.container}>
        <Card>
          <h3 className={styles.cardTitle}>Gang Of Four</h3>
          <p className={styles.text}>
            Este proyecto es una aplicación web interactiva para el análisis de regresión por mínimos cuadrados,
            enfocada en la relación entre la velocidad del viento y la potencia eólica generada.
          </p>
          <p className={styles.text}>
            La aplicación permite cargar datos, ajustar múltiples modelos (lineal, cuadrático y potencial), visualizar
            resultados y realizar diagnósticos de los residuos.
          </p>
        </Card>

        <Card>
          <h3 className={styles.cardTitle}>Tecnologías utilizadas</h3>
          <ul className={styles.techList}>
            <li>Next.js 15 (App Router)</li>
            <li>React 19</li>
            <li>TypeScript</li>
            <li>PapaParse (procesamiento CSV)</li>
            <li>MathJax (renderizado de ecuaciones)</li>
            <li>CSS Modules</li>
          </ul>
        </Card>

        <Card>
          <h3 className={styles.cardTitle}>Equipo</h3>
          <p className={styles.text}>
            Desarrollado por el equipo Gang Of Four como parte de un proyecto educativo sobre métodos numéricos y
            análisis de datos.
          </p>
        </Card>
      </div>
    </div>
  )
}
